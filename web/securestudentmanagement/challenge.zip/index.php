<html>
<head>
<title>Student Management</title>
</head>
<body>
<?php
if(isset($_POST["username"])){
	$username = $_POST["username"];
}
else{
	$username = "";
}
if(isset($_POST["password"])){
	$password = $_POST["password"];
}
else{
	$password = "";
}

if(($username === "40000000")&&($password === "00000004")){
	echo '<h2>Login Successful</h2>
		<a href="bg/upload.html">Upload a register</a>';
}
else{
	echo '<html>
<h1>Student Managment Portal</h1>
<form action="index.php" method="POST">
<input type="text" name="username" placeholder="Username">
<input type="text" name="password" placeholder="Password">
<input type="submit" value="Log In">
</form></body>';
}
?>
<!-- Default User is 40000000 -->
</body>
</html>
